import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  public max:number = 200;
  public currentValue:number;
  public type:string;

  public stackedValues:any[] = [];

  constructor() {
    this.generateNewProgressValues();
    this.generateStackedValues();
  }

  private generateNewProgressValues() {
    let value = Math.floor((Math.random() * 100) + 1);
    let type:string;

    if (value < 20) {
      type = 'success';
    } else if (value < 40) {
      type = 'info';
    } else if (value < 60) {
      type = 'warning';
    } else {
      type = 'danger';
    }
    this.currentValue = value;
    this.type = type;
  };

  private generateStackedValues() {
    let types = ['success', 'info', 'warning', 'danger'];

    this.stackedValues = [];
    let total = 0;
    for (let i = 0, n = Math.floor((Math.random() * 4) + 1); i < n; i++) {
      let index = Math.floor((Math.random() * 4));
      let value = Math.floor((Math.random() * 30) + 1);
      total += value;
      this.stackedValues.push({
        value: value,
        max: value,
        type: types[index]
      });
    }
  };
}
